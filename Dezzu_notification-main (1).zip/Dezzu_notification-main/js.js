
window.addEventListener('message', (event) => {
    if (event.data.action === "Dezzu_notification") {
        createNotify(event.data.title,event.data.desc, event.data.duration,event.data.wait);
    }
})


console.log('siup');



function createNotify(title,desc, duration, wait){
    $('.notify').animate({ right:'20px'}, duration);
    '<div class="title">${desc}</div>'
    '<div class="text">${desc}</div>'
    $('.title').html(title);
    $('.text').html(desc);
    



    setTimeout(() => {
        $('.notify').animate({'right':'-360px'}, duration, function() {
        });
    }, wait);
}

