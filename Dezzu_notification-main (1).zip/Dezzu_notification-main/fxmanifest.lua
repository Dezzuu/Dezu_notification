fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'dezzu'
description 'sziro to cwelson'
version '1.0.0'

client_script {
    'client.lua',
}

ui_page 'index.html'

files {
    'index.html',
    'style.css',
    'js.js',
}