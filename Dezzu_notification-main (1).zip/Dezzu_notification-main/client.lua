exports('sendNotify', function(title, desc, duration, wait)
    if title == '-' then
        title = "Powiadomienie"
    end
    if desc == nil then
        desc = "Wszystkie skrypty zostały załadowane"
    end
    if duration == nil then
        duration = 1200
    end
    if wait == nil then
        wait = 5000
    end
    SendNUIMessage({
        action = 'Dezzu_notification',
        title = title,
        desc = desc,
        duration = duration,
        wait = wait
    })
end)

-- Funkcja pomocnicza do wyciągania tekstu z nawiasów
local function extractDesc(args)
    local desc = ""
    local inBrackets = false
    for _, word in ipairs(args) do
        if word:sub(1, 1) == '(' then
            inBrackets = true
            desc = word:sub(2)  -- Usuwamy nawias otwierający
        elseif word:sub(-1) == ')' then
            desc = desc .. " " .. word:sub(1, -2)  -- Usuwamy nawias zamykający
            inBrackets = false
        elseif inBrackets then
            desc = desc .. " " .. word
        end
    end
    return desc
end

RegisterCommand('dezzu', function(source, args)
    local title = args[1] or '-'
    local duration = tonumber(args[#args - 1]) or 1200  -- Przedostatni argument to duration
    local wait = tonumber(args[#args]) or 5000  -- Ostatni argument to wait
    local desc = extractDesc(args)  -- Wyciągnięcie tekstu z nawiasów
    exports['Dezzu_notification']:sendNotify(title, desc, duration, wait)
end, false)

